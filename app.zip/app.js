const express = require('express');
const app = express();
const fs = require('fs')
var https = require('https');
const socket = require('socket.io');

var privateKey = fs.readFileSync('servercirtficate.key');
var certificate = fs.readFileSync('servercirtficate.crt');

var credentials = { key: privateKey, cert: certificate };
var apps = https.createServer(credentials, app);

var nodemailer = require('nodemailer');




const cors = require('cors');

const dotenv = require('dotenv');
var bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const { check, validationResult } = require('express-validator');
let jsonFile = require('jsonfile');
var dateFormat = require("dateformat");
const { randomUUID, randomInt } = require('crypto');

dotenv.config({ path: './.env' })

app.use(bodyParser.json());

const db = require('./database/index')

const urlencoded = bodyParser.urlencoded({ extended: false })
    //error
cors.bind

app.use(function(req, res, next) {
    console.log(req.headers.origin);
    console.log(req.headers.referer);
    // if (req.headers.origin == 'http://localhost:4200' || req.headers.referer == 'http://localhost:4200/') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin , X-Requested-With, Content-Type, Accept');
    next();
    // } else {
    //     return res.sendStatus(401)
    // }
})
app.use('/api/login', require('./login/index'))

app.use(function(req, res, next) {
    console.log(req.headers.authorization);
    if (req.headers.authorization != '') {
        next()
    }
})

// app.use(function(req, res, next) {
//     if (req.secure) {
//         // request was via https, so do no special handling
//         next();
//     } else {
//         // request was via http, so redirect to https
//         res.redirect('https://' + req.headers.host + req.url);
//         return
//     }
// });
var server = apps.listen(443, '192.168.1.8', () => {
    console.log('server stated')
})
app.listen(80, '192.168.1.8', () => {


})

// const io = require("socket.io")(server, {
//     cors: {
//         origin: "*",
//         methods: ["GET", "POST"]
//     }
// });
// let x = true;
// io.sockets.on('connection', (socket) => {
//     const s = socket
//         // sendData(data, socket)
//     socket.on('data_all', function(data) {
//         sendData(data, s)
//     })
// })
// function sendData(data, socket) {
//     var usernames = String(data.username);
//     const dates = new Date();
//     var json = dateFormat(dates, "ddmmyyyyhhmmss")
//         // socket.emit(json)
//     db.query('SELECT * FROM `notifiction` WHERE `username` = ? && `status` = ? &&    `sent`=?  ', [usernames, 1, 1], (err, result) => {
//         if (!err) {
//             if (!result[0] == []) {
//                 const res = result
//                 db.query('UPDATE `notifiction` SET `sent`=? WHERE `username`  = ? && `sent`=? ', [2, usernames, 1], (err, result) => {
//                     if (!err) {
//                         socket.emit('data_all_response', { status: true, error: false, mes: res })
//                     } else {
//                     }
//                 })
//             } else {
//                 // res.send({ status: true, error: true, mes: "Something went wrong", error: err })
//                 socket.emit('data_all_response', { status: true, error: false, mes: "No New Data" })
//             }
//         } else {
//             // res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })
//         }
//     setTimeout(() => {
//         sendData(data, socket);
//     }, 1000);
// }

app.use('/api/teacher/notification', require('./ntifcation/index'))

//student
app.use('/api/student/video/poseter', require('./student/video_poster'))
app.use('/api/student/notes/pdf', require('./student/notes_pdf'))

app.use('/api/student/', require('./student/index'))
    // login 
app.use('/api/teacher/notification', require('./ntifcation/index'))
app.use('/api/teacher/upload_video_thumnail', require('./teacher/upload_video_thumnail'))
app.use('/api/teacher/upload_video_video', require('./teacher/upload_video_video'))
app.use('/api/teacher/notes', require('./teacher/notes'))


app.use('/api/teacher/playvideo/poster', require('./teacher/poster'))
app.use('/api/teacher/playvideo', require('./teacher/playvideo'))


app.use('/api/teacher', require('./teacher/fetch_video'))

function addjson(data) {
    const dates = new Date();
    var json = { date: dateFormat(dates, "dd.mm.yyyy"), maindata: data }
    jsonFile.writeFile('json/newarivals.json', json);

}