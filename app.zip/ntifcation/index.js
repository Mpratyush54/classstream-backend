const express = require('express')
const app = express.Router()
var randomstring = require("randomstring");
var dateFormat = require("dateformat");
const sizeOf = require('image-size')
var UserAgent = require('user-agents');

// seen




const db = require('../database/index')

// const dotenv = require('dotenv');
var bodyParser = require('body-parser');
const { check, validationResult } = require('express-validator');





const urlencoded = bodyParser.urlencoded({ extended: false })
const webpush = require('web-push');
const { lchmod } = require('fs');
const { url } = require('inspector');
const { json } = require('body-parser');

app.use('/',
    (req, res, next) => {

        // email
        var usernames = String(req.body.username);
        var emails = String(req.body.email);
        var query_tokens = String(req.body.query_token);

        db.query('SELECT `username`,  `token`,  `email` FROM `loginlog` WHERE `token` = ?', [query_tokens], (err, result) => {
            if (!err) {

                if (!result[0] == []) {



                    // res.send({ result })
                    rec_username = result[0].username
                    rec_emails = result[0].email
                    rec_query_tokens = result[0].token


                    if (usernames == rec_username & emails == rec_emails && query_tokens == rec_query_tokens) {
                        next()
                    } else {
                        return res.status(403).json({ status: true, error: true, mes: "user is loged out" })

                    }
                } else {
                    res.send({ status: true, error: true, mes: "Something went wrong", error: err })
                }
            } else {
                return res.status(403).json({ status: true, error: true, mes: "user is loged outs" })

            }
        })
    })


app.post('/check-notifaction-custom', (req, res) => {
    var usernames = String(req.body.username);

    db.query('SELECT * FROM `notifiction` WHERE  `by` = ? GROUP BY `sttus_seen_time`   ', [usernames], (err, result) => {
        if (!err) {

            if (!result[0] == []) {

                res.send({ status: true, error: false, mes: result })

            } else {
                res.send({ status: true, error: true, mes: "Something went wrong", errora: err, mes: result })
            }
        } else {
            console.log(err);
            return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

        }
    })
})
app.post('/check-notifaction-custom2', (req, res) => {
    var usernames = String(req.body.username);
    var data = String(req.body.data);

    db.query('SELECT * FROM `notifiction` WHERE   `sttus_seen_time` = ?', [data], (err, result) => {
        if (!err) {

            if (!result[0] == []) {

                res.send({ status: true, error: false, mes: result })

            } else {
                res.send({ status: true, error: true, mes: "Something went wrong", errora: err })
            }
        } else {
            console.log(err);
            return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

        }
    })
})
app.post('/know_class', (req, res) => {
    var usernames = String(req.body.username);
    var usename = String(req.body.data);

    db.query('SELECT  `class` FROM `login` WHERE `username` = ?', [usename], (err, result) => {
        if (!err) {

            if (!result[0] == []) {

                res.send({ status: true, error: false, mes: result })

            } else {
                res.send({ status: true, error: true, mes: "Something went wrong", errora: err })
            }
        } else {
            return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

        }
    })
})

app.post('/check-notifaction', (req, res) => {
    var usernames = String(req.body.username);

    db.query('SELECT * FROM `notifiction` WHERE  `username` = ? && `status`  = ? && `sent`=? ', [usernames, 1, 1], (err, result) => {
        if (!err) {

            if (!result[0] == []) {
                const dates = new Date();
                var json = dateFormat(dates, "ddmmyyyyhhmmss")

                res.send({ status: true, error: false, notify: result, time: json })
                db.query('UPDATE `notifiction` SET `sent`=? WHERE `username`  = ?', [2, usernames], (err, result) => {
                    if (!err) {


                    } else {
                        return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

                    }
                })

            } else {
                res.send({ status: true, error: true, mes: "Something went wrong", errora: err })
            }
        } else {
            return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

        }
    })
})
app.post('/check-notifaction-all', (req, res) => {

    var usernames = String(req.body.username);

    db.query('SELECT * FROM `notifiction` WHERE  `username` = ? && `status`  = ? ', [usernames, 1], (err, result) => {
        if (!err) {

            if (!result[0] == []) {
                const dates = new Date();
                var json = dateFormat(dates, "ddmmyyyyhhmmss")

                res.send({ status: true, error: false, notify: result, time: json })
                db.query('UPDATE `notifiction` SET `sent`=? WHERE `username`  = ?', [2, usernames], (err, result) => {
                    if (!err) {


                    } else {
                        return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

                    }
                })

            } else {
                res.send({ status: true, error: true, mes: "Something went wrong", error: err })
            }
        } else {
            return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

        }
    })
})

app.post('/seen', (req, res) => {
    let id = Number(req.body.id);
    db.query('UPDATE `notifiction` SET `status`=? WHERE id  = ?', [2, id], (err, result) => {
        if (!err) {


        } else {
            return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

        }
    })
})


app.post('/data', (req, res) => {
    const publicKey =
        'BL1k4svygg7piYjqcY8MH8XW7QAt5T9QU20hWn9wQgLgw6zgVpOOHYmGza1kknjWuc1S-rkkKKazzqGBXpEEWzU';
    const privateKey = 'ywKhgIcofvO6RRiQXufih8dhEbyibWR-epftZSFHIjg';

    const sub = req.body.data
    webpush.setVapidDetails('mailto:mpratyush54@gmail.com', publicKey, privateKey);

    const payLoad = {
        notification: {
            data: { url: 'https://pratyush.ddns.net:444/assets/images/icon/avatar-01.jpg' },
            title: 'Hello User You are sucessfully regesterd for notifcation',
            vibrate: [100, 50, 100],
        },
    };




    const usernames = String(req.body.username);

    db.query('SELECT  `testing_array` FROM `login` WHERE `username` = ?', [usernames], (err, result) => {
        if (!err) {


            const userAgents = new UserAgent();
            const useragent2 = [userAgents]
            var userAgent = JSON.stringify(useragent2)
            var data = { useragents: userAgents.data, userAgent2: req.body.useragent, data: userAgent }
            const data4 = [data, req.body.data]
            var data2 = [data4]
            var data3 = JSON.stringify(data2)

            console.log(data);



            var data_recived = JSON.parse(result[0].testing_array)
            var daf = false

            for (let i = 0; i < result.length; i++) {

                if (data_recived[i].data == req.body.data) {


                } else {

                    db.query('UPDATE `login` SET `testing_array` = ? WHERE `username` = ?', [data3, usernames], (err, result) => {
                        if (!err) {
                            return res.send({ status: true, error: false })

                        } else {
                            console.log(err);
                            return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

                        }
                    })
                }


            }

        } else {

        }
    })


    // db.query('SELECT  `testing_array` FROM `login` WHERE `username` = ?', [usernames], (err, result) => {
    //     if (!err) {
    //         console.log(result);





    //         // if (result[0].no_of_devices == 0) {

    //         //     db.query('UPDATE `login` SET `divece_1`=?,`no_of_devices`=? WHERE `username` = ? ', [JSON.stringify(req.body.data), 1, usernames], (err, result) => {
    //         //         if (!err) {
    //         //             Promise.resolve(webpush.sendNotification(sub, JSON.stringify(payLoad))).then(() => {
    //         //                 res.status(200).json({ status: true, error: false, mes: "succefull" })
    //         //             }).catch(function(ex) {
    //         //                 return console.log(ex);
    //         //             })
    //         //             console.log('ssssssssssssss');
    //         //         } else {
    //         //             // return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })
    //         //             console.log(err);
    //         //         }
    //         //     })
    //         // } else if (result[0].no_of_devices == 1) {



    //         //     if (result[0].divece_1 == JSON.stringify(req.body.data) || result[0].divece_2 == JSON.stringify(req.body.data) || result[0].divece_3 == JSON.stringify(req.body.data)) {

    //         //     } else {
    //         //         db.query('UPDATE `login` SET `divece_2`=?,`no_of_devices`=? WHERE `username` = ? ', [JSON.stringify(req.body.data), 2, usernames], (err, result) => {
    //         //             if (!err) {
    //         //                 Promise.resolve(webpush.sendNotification(sub, JSON.stringify(payLoad))).then(() => {
    //         //                     res.status(200).json({ status: true, error: false, mes: "succefull" })
    //         //                 }).catch(function(ex) {
    //         //                     return console.log(ex);
    //         //                 })
    //         //                 console.log('ssssssssssssss');
    //         //             } else {
    //         //                 // return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })
    //         //                 console.log(err);
    //         //             }
    //         //         })
    //         //     }
    //         // } else if (result[0].no_of_devices == 2) {


    //         //     if (result[0].divece_1 == JSON.stringify(req.body.data) || result[0].divece_2 == JSON.stringify(req.body.data) || result[0].divece_3 == JSON.stringify(req.body.data)) {

    //         //     } else {

    //         //         db.query('UPDATE `login` SET `divece_3`=?,`no_of_devices`=? WHERE `username` = ? ', [JSON.stringify(req.body.data), 3, usernames], (err, result) => {
    //         //             if (!err) {
    //         //                 Promise.resolve(webpush.sendNotification(sub, JSON.stringify(payLoad))).then(() => {
    //         //                     res.status(200).json({ status: true, error: false, mes: "succefull" })
    //         //                 }).catch(function(ex) {
    //         //                     return console.log(ex);
    //         //                 })
    //         //                 console.log('ssssssssssssss');
    //         //             } else {
    //         //                 // return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })
    //         //                 console.log(err);
    //         //             }
    //         //         })
    //         //     }
    //         // } else if (result[0].no_of_devices == 3) {


    //         //     if (result[0].divece_1 == JSON.stringify(req.body.data) || result[0].divece_2 == JSON.stringify(req.body.data) || result[0].divece_3 == JSON.stringify(req.body.data)) {

    //         //     } else {
    //         //         db.query('UPDATE `login` SET `divece_1`=?,`no_of_devices`=? WHERE `username` = ? ', [JSON.stringify(req.body.data), 3, usernames], (err, result) => {
    //         //             if (!err) {
    //         //                 Promise.resolve(webpush.sendNotification(sub, JSON.stringify(payLoad))).then(() => {
    //         //                     res.status(200).json({ status: true, error: false, mes: "succefull" })
    //         //                 }).catch(function(ex) {
    //         //                     return console.log(ex);
    //         //                 })
    //         //                 console.log('ssssssssssssss');
    //         //             } else {
    //         //                 // return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })
    //         //                 console.log(err);
    //         //             }
    //         //         })
    //         //     }
    //         // }
    //     } else {
    //         return res.status(500).json({ status: true, error: true, mes: "Soemthing Went Wrong" })

    //     }
    // })


});


app.post('/new', (req, res) => {
    const usernames = String(req.body.username);
    const data = String(req.body.data);
    const heading = String(req.body.data.Title);
    const Body = String(req.body.data.Body);
    // console.log(heading);
    const dates = new Date();



    const Class = req.body.data.class;
    db.query('SELECT `username`,`testing_array`  FROM `login` WHERE `class` = ?', [Class], (err, result) => {
        if (!err) {
            console.log('recived eq');
            const random = Math.floor(Math.random() * (100000 - 999999) + 100000)
            for (let i = 0; i < result.length; i++) {
                const url = "https://pratyush.gq/login"
                var data = result[i]
                const all_data = JSON.parse(result[i].testing_array)
                const username_sent = result[i].username

                console.log(username_sent);
                db.query('INSERT INTO `notifiction`(`username`, `photo`, `heading`, `onclick`, `date`,   `body`,   `by` ,`sttus_seen_time`) VALUES (?,?,?,?,?,?,? , ?)', [username_sent, 'none', heading, url, dateFormat(dates, "dd-mm-yyyy"), Body, usernames, random], (err, result) => {
                    if (!err) {
                        const publicKey =
                            'BL1k4svygg7piYjqcY8MH8XW7QAt5T9QU20hWn9wQgLgw6zgVpOOHYmGza1kknjWuc1S-rkkKKazzqGBXpEEWzU';
                        const privateKey = 'ywKhgIcofvO6RRiQXufih8dhEbyibWR-epftZSFHIjg';

                        webpush.setVapidDetails('mailto:mpratyush54@gmail.com', publicKey, privateKey);

                        const payLoad = {
                            notification: {
                                data: { url: 'https://pratyush.gq/assets/images/icon/avatar-01.jpg' },
                                image: "https://pratyush.gq/assets/images/icon/avatar-01.jpg",
                                icon: 'https://pratyush.gq/assets/images/icon/avatar-01.jpg',
                                title: `${heading}`,
                                body: `${Body}`,
                                vibrate: [100, 50, 100],
                            },
                        };
                        let y = 0;

                        for (let i = 0; i < all_data.length; i++) {
                            var dd = all_data[y].data
                            Promise.resolve(webpush.sendNotification(dd, JSON.stringify(payLoad))).then(() => {
                                console.log('sucessful');
                            }).catch(function(ex) {
                                return console.log(ex);
                            })
                            y++

                        }


                    } else {
                        console.log(err);
                    }
                })
            }


            res.send({ status: true, error: false, mes: random })
        } else {
            console.log(err);
            return res.status(500).json({ status: true, error: err, mes: "Soemthing Went Wrong" })

        }
    })


});
module.exports = app