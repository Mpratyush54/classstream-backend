const mysql = require('mysql');
const Buffer = require('safer-buffer').Buffer

const db = mysql.createConnection({
    host: process.env.host,
    user: process.env.user,
    password: process.env.password,
    database: process.env.database,
    multipleStatements: true
})
db.connect((error) => {
    if (error) {
        if (error.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
            handleDisconnect(); // lost due to either server restart, or a
        } else { // connnection idle timeout (the wait_timeout
            throw error; // server variable configures this)
        }
    } else {
        console.log('mysql connected')
    }


})

function handleDisconnect() {

    db.connect((error) => {
        if (error) {
            if (error.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
                setTimeout(handleDisconnect, 2000)
            } else { // connnection idle timeout (the wait_timeout
                throw error; // server variable configures this)
            }
        } else {
            handleDisconnect()
            console.log('mysql connected')
        }


    })
}

module.exports = db