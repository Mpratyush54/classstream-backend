const config = {
    server: {
        secret: 'kjVkuti2xAyF3JGCzSZTk0YWM5JhI9mgQW4rytXc',

    },
    rtmp: {
        port: 1935,
        chunk_size: 60000,
        gop_cache: true,
        ping: 30,
        ping_timeout: 60
    },
    http: {
        port: 8000,
        allow_origin: '*',
        mediaroot: './medias'

    },


    fission: {
        ffmpeg: '/../../ffmpeg/bin/ffmpeg.exe',
        tasks: [{
                rule: "game/*",
                model: [{
                        ab: "128k",
                        vb: "1500k",
                        vs: "1280x720",
                        vf: "30",
                    },
                    {
                        ab: "96k",
                        vb: "1000k",
                        vs: "854x480",
                        vf: "24",
                    },
                    {
                        ab: "96k",
                        vb: "600k",
                        vs: "640x360",
                        vf: "20",
                    },
                ]
            },
            {
                rule: "show/*",
                model: [{
                        ab: "128k",
                        vb: "1500k",
                        vs: "720x1280",
                        vf: "30",
                    },
                    {
                        ab: "96k",
                        vb: "1000k",
                        vs: "480x854",
                        vf: "24",
                    },
                    {
                        ab: "64k",
                        vb: "600k",
                        vs: "360x640",
                        vf: "20",
                    },
                ]
            },
        ]
    },

    trans: {
        ffmpeg: '/../../ffmpeg/bin/ffmpeg.exe',

        tasks: [{
            mp4: true,
            mp4Flags: '[movflags=frag_keyframe+empty_moov]',
            app: 'live',
            vc: "copy",
            vcParam: [],
            ac: "aac",
            acParam: ['-ab', '64k', '-ac', '1', '-ar', '44100'],
            rtmp: true,
            rtmpApp: 'live2',
            hls: true,
            hlsFlags: '[hls_time=2:hls_list_size=3:hls_flags=delete_segments]',

        }]
    }







};

module.exports = config;