const NodeMediaServer = require('node-media-server')
const dotenv = require('dotenv');
dotenv.config({ path: './.env' })
const db = require('../database/index')
const fs = require('fs')

config = {
    server: {
        secret: 'kjVkuti2xAyF3JGCzSZTk0YWM5JhI9mgQW4rytXc',

    },
    rtmp: {
        port: 1935,
        chunk_size: 60000,
        gop_cache: true,
        ping: 30,
        ping_timeout: 60
    },
    http: {
        port: 8000,
        allow_origin: '*',
        mediaroot: './media/'

    },


    fission: {
        ffmpeg: '/../../ffmpeg/bin/ffmpeg.exe',
        tasks: [{
                rule: "live",
                model: [{
                        ab: "128k",
                        vb: "1500k",
                        vs: "1280x720",
                        vf: "30",
                    },
                    {
                        ab: "96k",
                        vb: "1000k",
                        vs: "854x480",
                        vf: "24",
                    },
                    {
                        ab: "96k",
                        vb: "600k",
                        vs: "640x360",
                        vf: "20",
                    },
                ]
            },
            {
                rule: "show/*",
                model: [{
                        ab: "128k",
                        vb: "1500k",
                        vs: "720x1280",
                        vf: "30",
                    },
                    {
                        ab: "96k",
                        vb: "1000k",
                        vs: "480x854",
                        vf: "24",
                    },
                    {
                        ab: "64k",
                        vb: "600k",
                        vs: "360x640",
                        vf: "20",
                    },
                ]
            },
        ]
    },

    trans: {
        ffmpeg: '/../../ffmpeg/bin/ffmpeg.exe',

        tasks: [{
            app: 'live',
            mp4: true,

            mp4: true,
            mp4Flags: '[movflags=frag_keyframe+empty_moov]',
            app: 'live',
            vc: "copy",
            vcParam: [],
            ac: "aac",
            acParam: ['-ab', '64k', '-ac', '1', '-ar', '44100'],
            rtmp: true,
            rtmpApp: 'live2',
            hls: true,
            hlsFlags: '[hls_time=2:hls_list_size=3:hls_flags=delete_segments]',
            app: 'live',
            mp4: true,
            mp4Flags: '[movflags=frag_keyframe+empty_moov]',


        }]
    }







};


nms = new NodeMediaServer(config);
const { subscribe } = require('../teacher/connetion_teacher');
const verify = require('../teacher/connetion_teacher')


nms.on('prePublish', async(id, StreamPath, args) => {

    let stream_key = getStreamKeyFromStreamPath(StreamPath)
    console.log('[NodeEvent on prePublish]', `id=${id} StreamPath=${StreamPath} args=${JSON.stringify(args)}`);
    console.log(stream_key);
    // 61f43967d2b19b8810a9c8eef801c7a9da9495711ce81f2d0e51cbc55bcbde66
    db.query('  SELECT `hash_code` FROM `live_current` WHERE  `hash_code` = ?', [stream_key], (err, result) => {
        if (!err) {
            console.log(result);

            if (result.length >= 1) {
                db.query('UPDATE `live_current` SET `connnction_status`= ?  WHERE `hash_code` = ?', ['true', stream_key], (err, result1) => {
                    if (!err) {
                        console.log('i was fv');
                        return true
                    } else {

                    }
                })
            } else {
                let session = nms.getSession(id);
                session.reject();
            }

        } else {
            let session = nms.getSession(id);
            session.reject();
        }
    })










})
nms.on('donePublish', (id, StreamPath, args) => {
    let stream_key = getStreamKeyFromStreamPath(StreamPath)
let path_files = './media/live/' + stream_key
allfilesum= []
// allfile sim file name and sum 
  fs.readdirSync(path_files).forEach(file => {
      
        let path = file

     let parts = path.split('-');
     let parts5 = parts[5].split('.')

let sum = parseInt(parts[0])+parseInt(parts[1])+parseInt(parts[2])+parseInt(parts[3])+parseInt(parts[4])+parseInt(parts5[0])
allfilesum.push({
    path:file,
    date_sum:sum
 });



      })
      console.log(allfilesum);
    console.log('[NodeEvent on doneConnect]', `id=${id} args=${JSON.stringify(args)}`);
    console.log('____________________________________________________');
    console.log('____________________________________________________');
    console.log('____________________________________________________');
    console.log('I was run afterr connection end');
    console.log('____________________________________________________');
    console.log('____________________________________________________');

    db.query('UPDATE `live_current` SET `connnction_status`= ?  WHERE `hash_code` = ?', ['false', stream_key], (err, result1) => {
        if (!err) {
            console.log('i was fv');
            return true
        } else {

        }
    })
});

nms.on('prePlay', (id, StreamPath, args) => {
    console.log('[NodeEvent on prePlay]', `id=${id} StreamPath=${StreamPath} args=${JSON.stringify(args)}`);
    console.log('____________________________________________________');
    console.log('____________________________________________________');
    console.log('____________________________________________________');
    console.log('I was run afterr a video was palyed');
    console.log('____________________________________________________');
    console.log('____________________________________________________');
});
nms.on('donePlay', (id, StreamPath, args) => {
    console.log('[NodeEvent on prePlay]', `id=${id} StreamPath=${StreamPath} args=${JSON.stringify(args)}`);
    console.log('____________________________________________________');
    console.log('____________________________________________________');
    console.log('____________________________________________________');
    console.log('I was run afterr a video was paused');
    console.log('____________________________________________________');
    console.log('____________________________________________________');
});

const getStreamKeyFromStreamPath = (path) => {
    let parts = path.split('/');
    return parts[parts.length - 1];
};

module.exports = nms;